<template>
  <div class="empty-title"></div>
  <ul class="exercises-list">
    <li
        v-for="(exercise) in currentValue"
        :key="exercise.id"
        @click="selectExerciseId(exercise)"
        class="exercises-list__item"
        :style="[ exercise.isSelected ? activeColorObj : '' ]"
    >
      {{ exercise.name }}
      <Icon :iconName="exercise.isSelected ? 'minus' : 'plus'"/>
    </li>
  </ul>

</template>

<script setup>
import {computed, ref, watch} from "vue";
import {useStore} from "@/store";
import Icon from "../UI/Icon.vue";

const store = useStore()

const props = defineProps({
  groupId: Number,
  exercisesList: Array
})

const computedColor = computed(() => `rgb(${store.currentTaskColor})`)
const currentValue = computed(() => props.exercisesList.filter(el => el.categoryId === props.groupId))

watch(() => store.currentExercise, (value) => {
  if(!value.length) {
    currentValue.value.forEach(element => {
      element.isSelected = false
    });
  }
})

const activeColorObj = ref({
  backgroundColor: computedColor,
  color: 'var(--c-bg)',
})

const selectExerciseId = (exercise) => {
  exercise.isSelected = !exercise.isSelected

  if(!store.currentExercise.includes(exercise)) {
    store.currentExercise = [...store.currentExercise, exercise]
  }
  else {
    store.currentExercise = store.currentExercise.filter(el => el.id !== exercise.id)
  }
}
</script>

<style scoped lang="scss">
.exercises-list {
  width: 250px;
  border-left: 1px solid var(--c-border);
}

.exercises-list__item {
  display: flex;
  align-items: center;
  padding: 9px 16px;
  cursor: pointer;
  font-size: 13px;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
  max-width: 100%;
  height: 34px;

  &:hover {
    background-color: var(--c-block-hover);
  }
}

svg {
  margin-left: auto;
  width: 16px;
  fill: var(--c-text-light)
}
</style>