<template>
  <div
      class="modal-top"
      :style="{backgroundColor: 'rgb(' + store.currentTaskColor + ')' }"
  >
    <div
        :class="{saveIcon: workoutName}"
        class="save-workout-btn"
        @click="workoutNameToStore">
      сохранить
      <Icon v-if="workoutName"
          iconName="floppy-disk"
          class="check-icon"/>
    </div>

    <Icon
        class="closeIcon"
        iconName="xmark"
        @click="close"/>
  </div>
</template>

<script setup>
import Icon from '@/components/UI/Icon'
import { useStore } from '@/store'

const props = defineProps({
  workoutName: String,
  dayData: Object,
})

const store = useStore()

const emit = defineEmits(['workoutNameToStore', 'close'])
const workoutNameToStore = () => emit('workoutNameToStore')
const close = () => emit('close')
</script>

<style lang="scss" scoped>
.modal-top {
  display: flex;
  justify-content: space-between;
  padding: 12px 16px;
}

.save-workout-btn {
  display: flex;
  align-items: center;
  margin-right: 16px;
  font-size: 10px;
  text-transform: uppercase;
  font-weight: 600;
  color: var(--c-text-light);

  &.saveIcon {
    color: var(--c-bg);
    cursor: pointer;
  }
}

.check-icon {
  fill: var(--c-bg);
  width: 18px;
  height: 18px;
  margin-left: 8px;
}

.closeIcon {
  cursor: pointer;
  fill: var(--c-bg);
}
</style>